#/usr/bin bash

export ECR_DOMAIN="193634490577.dkr.ecr.ap-northeast-2.amazonaws.com"
export STAGE="local"

docker-compose down
