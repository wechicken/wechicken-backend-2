#/usr/bin bash

kill -9 $(pgrep -f "processName.*Wechicken")
